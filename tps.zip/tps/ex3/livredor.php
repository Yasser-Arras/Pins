<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dorm Feedback</title>
</head>

<body>
    <div id="livre" style="background-color: gold; padding: 20px;">
        <fieldset>
            <legend>Donner votre avis sur PHP</legend>
            <form method="POST">
                <label for="nom">Name:</label>
                <input type="text" id="nom" name="nom" ><br><br>

                <label for="mail">Email:</label>
                <input type="email" id="mail" name="mail" ><br><br>

                <label for="commentaires">Your Comment:</label><br>
                <textarea id="commentaires" name="commentaires" ></textarea><br><br>

                <button type="submit" name="afficher">Afficher</button>
                <button type="submit" name="envoyer">Envoyer</button>
            </form>
        </fieldset>

        <hr>

        <?php
        // if form submitted get data
        if (isset($_POST['envoyer'])) {
            $name = htmlspecialchars($_POST['nom']);
            $email = htmlspecialchars($_POST['mail']);
            $comment = htmlspecialchars($_POST['commentaires']);
            $timestamp = date('Y-m-d H:i:s'); //timestamp

            // preparing data for json putting them in a dictionary
            $dataItem = [
                'name' => $name,
                'email' => $email,
                'timestamp' => $timestamp,
                'comment' => $comment
            ];

            $dataList = []; //initialiser l'array
            if (file_exists('datalist.json')) { //if the file exists to get its data
                $dataList = json_decode(file_get_contents('datalist.json'), true); ///get file content as string and convert it to json
                //true param returns data as an php array, false (default) gives it as an objec.
            }

            // add the prepared data to the decoded json array (append)
            $dataList[] = $dataItem;

            // encode the finished datalist array as the new json file
            file_put_contents('datalist.json', json_encode($dataList, JSON_PRETTY_PRINT));
            //file_put_contents(target file, content) json_encode(stuff to encode, PRETTY_PRINT makes json formatted w spaces to be easily readable)
        }
        ?>

           
        <?php
        // if afficher is clicked
        if (isset($_POST['afficher'])) {
            // initialize array
            $dataList = [];
            if (file_exists('datalist.json')) {
                $dataList = json_decode(file_get_contents('datalist.json'), true); //copy/put json content into the array variable
            }

            $dataList = array_slice($dataList, -5); // get last 5 entries only
            $dataList = array_reverse($dataList); // reverse order to start from most recent

            if (count($dataList) > 0) { //if theres data in the json
                echo "<h2>Last Comments</h2>";

                // for each loop
                foreach ($dataList as $item) {
                    echo "<div style='margin-bottom: 20px;'>"; //open div
                    echo "<strong>Name:</strong> " . htmlspecialchars($item['name']) . "<br>"; //used h3 but it jumps line strong acts as span
                    echo "<strong>Email:</strong> " . htmlspecialchars($item['email']) . "<br>";
                    echo "<strong>Timestamp:</strong> " . htmlspecialchars($item['timestamp']) . "<br>";
                    echo "<strong>Comment:</strong><br>" . nl2br(htmlspecialchars($item['comment'])) . "<br>";
                    //since comments can have many spaces nl2br() converts them to <br> new line to <br>
                    echo "</div> <hr>"; //close div
                }
            } else {
                echo "No data yet...";
            }
        }
        ?>

    </div>
</body>

</html>
