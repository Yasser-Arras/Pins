<?php
if (isset($_GET['nom']) && isset($_GET['prenom']) && isset($_GET['sexe']) && isset($_GET['cours'])) {
    $nom = htmlspecialchars($_GET['nom']);
    $prenom = htmlspecialchars($_GET['prenom']);
    $sexe = htmlspecialchars($_GET['sexe']);
    $cours = $_GET['cours'];

    echo "<h2>Informations reçues :</h2>";
    echo "Nom : " . $nom . "<br>";
    echo "Prénom : " . $prenom . "<br>";
    echo "Sexe : " . $sexe . "<br>";
    echo "Niveau cours: " . $cours. "<br>";
} else {
    echo "veillez remplir tous les champs.";
}
?>
