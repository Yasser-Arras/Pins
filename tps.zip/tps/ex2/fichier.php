

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de Transfert de Fichier</title>
</head>
<body>
    <fieldset>
    <legend>Transferer un fichier</legend>
    <form action="" method="POST" enctype="multipart/form-data">
        <label for="fileUpload">Choisissez un fichier (max 1 Mo):</label>
        <input type="file" name="fileupload" id="fileupload" required>
        <button type="submit">Envoyer</button>
    </form>
    </fieldset>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') { //if method is post
    $file = $_FILES['fileupload']; //file
    $fileName = $file['name']; //filename
    $fileSize = $file['size']; //filesize
    $fileTmpName = $file['tmp_name']; //temporary filename used by php

    if ($fileSize > 1000000) { //check if filesize greater than 1,000,000 bytes/ 1 megabyte
        echo "<h3>Erreur, le fichier ne doit pas depasser 1 Mo.</h3>";
    } else {
        $uploadDir = 'uploads/'; //files folder (same place as this php file)
        $uploadPath = $uploadDir . basename($fileName); // folder + full filename (exemple.zip)

        if (move_uploaded_file($fileTmpName, $uploadPath)) { //if the file is uploaded to the folder/the path exists
            echo "<h3>vous avez bien transfere le fichier !</h3>";
            echo "<hr>";
            echo "Nom de fichier: " . htmlspecialchars($fileName) . "<br>";
            echo "Taille de fichier: " . number_format($fileSize / 1024, 2) . " Ko<br>";
        } else {
            echo "<h3>Erreur, le fichier na pas put etre transfere.</h3>";
        }
    }
}
?>
</body>
</html>
