<?php
require_once("connexion.php");

if (isset($_GET['id'])) {
    $produit_id = $_GET['id'];

    $sql = "DELETE FROM produits WHERE produit_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$produit_id]);

    header("Location: index.php");
    exit();
} else {
    echo "Aucun produit selectionnee.";
}
?>
