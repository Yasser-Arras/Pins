<?php
$dsn = "mysql:host=localhost;dbname=gestion_produits";
$user = "root";
$pwd = "";
try{
 $pdo = new PDO($dsn, $user, $pwd);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
}
catch(PDOException $e){
    echo "Error" . $e->getMessage();
}
?>