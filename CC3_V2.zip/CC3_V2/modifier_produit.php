<?php
require_once("connexion.php");

if (isset($_GET['id'])) {
    $produit_id = $_GET['id'];

    $sql = "SELECT * FROM produits WHERE produit_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$produit_id]);
    $produit = $stmt->fetch();

    if (!$produit) {
        echo "Produit introuvable";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $titre = $_POST['titre'];
        $prix = $_POST['prix'];
        $categorie = trim($_POST['categorie']);

        if ($titre && $prix && $categorie) {
            $sql2 = "UPDATE produits SET titre = ?, prix = ?, categorie = ? WHERE produit_id = ?";
            $stmt2 = $pdo->prepare($sql2);
            $stmt2->execute([$titre, $prix, $categorie, $produit_id]);

            header("Location: index.php");
            exit;
        } else {
            echo "Veuillez remplir tous les champs.";
        }
    }
} else {
    echo "Aucun produit selectionnee.";
    exit;
}
?>

<h2>Modifier le produit</h2>

    <form method="post">

        Titre: <input type="text" name="titre" value="<?= htmlspecialchars($produit['titre']) ?>" required><br>
        Prix: <input type="number" name="prix" value="<?= htmlspecialchars($produit['prix']) ?>" required><br>
        Catégorie: <input type="text" name="categorie" value="<?= htmlspecialchars($produit['categorie']) ?>" required><br>
        <input type="submit" value="Modifier">
    </form>
