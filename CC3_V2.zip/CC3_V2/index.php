<?php
require_once("connexion.php");
$sql = "SELECT * FROM produits";
$query = $pdo->prepare($sql);
$query->execute();
$produits = $query->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Gestion des produits</h1> 
    <h2>Ajouter un produit</h2> 
    <form action=<?php echo $_SERVER["PHP_SELF"]?> method="post"> 
        Titre: <input type="text" name="titre" required><br> 
        Prix: <input type="number" name="prix" required><br> 
        Catégorie: <input type="text" name="categorie" required><br> 
        <input type="submit" name="ajouter_produit" value="Ajouter produit"> 
    </form>
    <?php

    if (isset($_POST['ajouter_produit'])) {
        $titre = trim($_POST['titre']);
        $prix = $_POST['prix'];
        $categorie = trim($_POST['categorie']);

        if ($titre && $prix && $categorie) {
            $sql = "INSERT INTO produits (titre, prix, categorie) VALUES (?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$titre, $prix, $categorie]);
            echo "Produit ajoute avec succes!";
        } else {
            echo "Erreur:tous les champs sont requis";
        }
    }
?>

    <h2>Liste des produits</h2>
    <table border="1">
    <tr>
        <th>Titre</th>
        <th>Prix</th>
        <th>Categorie</th>
        <th>Actions</th>
    </tr>
    <?php
    foreach ($produits as $produit) {
        echo '<tr>
            <td>'.htmlspecialchars($produit['titre']).'</td>
            <td>'.htmlspecialchars($produit['prix']) .' €</td>
            <td>'.htmlspecialchars($produit['categorie']).'</td>
            <td>
                <a href="modifier_produit.php?id='.$produit['produit_id'].'">   Modifier  </a> |
                <a href="supprimer_produit.php?id='.$produit['produit_id'].'" onclick="return confirm(\'Confirmer la suppression?\')  ">Supprimer</a>
            </td>
        </tr>';
    }
    
    ?>
    </table>
</body>
</html>