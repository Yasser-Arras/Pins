let exemple = document.getElementById("contact"); 
let template = exemple.cloneNode(true);
exemple.remove(); 

let form = document.getElementById("form");
let tbody = document.querySelector("tbody");

let contacts = JSON.parse(localStorage.getItem("contacts")) || []; 

function saveContacts() { /*Helper function - saves contacts table in 'localstorage' as stringified json*/
    localStorage.setItem("contacts", JSON.stringify(contacts));
}

function updateTable() { /* refreshes display table - reinsert all saved contacts*/
    tbody.innerHTML = '';
    contacts.forEach((c, index) => {
        let row = template.cloneNode(true);

        row.querySelector(".nom").textContent = c.nom;
        row.querySelector(".email").textContent = c.email;
        row.querySelector(".tel").textContent = c.tel;

        row.querySelector(".actions .edit").onclick = () => editContact(index);
        row.querySelector(".actions .delete").onclick = () => deleteContact(index);

        tbody.appendChild(row);
    });
}

function editContact(index) { 
    let contact = contacts[index]; /* select specific contact in our data table*/ 
    document.getElementById("nom").value = contact.nom; /* set form placeholder text as current contact data */ 
    document.getElementById("email").value = contact.email;
    document.getElementById("tel").value = contact.tel;
    document.getElementById("appliquer").setAttribute("value", "Modifier") /* switch form submit button to 'Modifier'*/ 
    form.onsubmit = () => updateContact(index); /*Call Update function once ur done editing*/ 
}

function updateContact(index) {
    contacts[index] = { /* index specific contact object in table*/ 

        nom: document.getElementById("nom").value, /*Update its data to info typed in form */ 
        email: document.getElementById("email").value,
        tel: document.getElementById("tel").value
    };
    saveContacts(); /* call func that saves contacts to localstorage*/ 
    updateTable(); /* func that refreshes display*/ 
    form.reset(); /* clear the form */ 
    document.getElementById("appliquer").setAttribute("value", "Ajouter") /* change form submit button text back to 'Ajouter'*/ 
    form.onsubmit = addContact;  /* change form onsubmitted mode to adding/default*/ 
}

function addContact(e) {
    e.preventDefault();

    let nom = document.getElementById("nom").value;
    let email = document.getElementById("email").value.trim();
    let tel = document.getElementById("tel").value.trim();

    // Check if one of them is empty
    if (!nom || !email || !tel) {
        alert("Tous les champs doivent être remplis.");
        return;
    }
    contacts.push({ nom, email, tel });

    saveContacts();
    updateTable();
    form.reset();
}


function deleteContact(index) {
    contacts.splice(index, 1);/*delete specific indexed contact from data table*/
    /*save and refresh display and form*/
    saveContacts();
    updateTable();
}


/*Initially set form onsubmit and refresh table*/
form.onsubmit = addContact;
updateTable();
